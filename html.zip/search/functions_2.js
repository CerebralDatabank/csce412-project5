var searchData=
[
  ['iprange_0',['IPRange',['../class_i_p_range.html#a9539cfa7a21171f92038a7cb7fcb70ad',1,'IPRange']]],
  ['isfree_1',['isFree',['../class_web_server.html#ab81ab3fb043d66ae6a0f54d7d199b689',1,'WebServer']]]
];
